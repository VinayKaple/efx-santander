# efx-santander

Just go to driver class and run it.

Console will show two outputs

1. Live FX prices with commission added
2. Latest price for given/known FX e.g. "EUR/JPY"

