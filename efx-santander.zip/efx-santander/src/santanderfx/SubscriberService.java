package santanderfx;

public interface SubscriberService {
	
	void onMessage(String i);
	
}
